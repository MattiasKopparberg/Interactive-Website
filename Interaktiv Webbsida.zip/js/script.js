document.querySelector(".hamburger").addEventListener("click", function () {
  document.querySelector(".navContent").classList.toggle("active");
});
window.addEventListener("scroll", () => {
  let header = document.querySelector("header");
  let BTN = document.querySelector("hamburger");
  if (window.scrollY > 50) {
    header.classList.add("shrink");
    BTN.classList.add("shrink");
  } else {
    header.classList.remove("shrink");
    BTN.classList.remove("shrink");
  }
});
const filterDropdown = document.getElementById("dishFilter");
filterDropdown.addEventListener("change", function () {
  const selectedCategory = filterDropdown.value;
  const dishSections = document.querySelectorAll(".column");
  dishSections.forEach((section) => {
    if (selectedCategory === "all") {
      section.classList.remove("hidden");
    } else {
      section.classList.toggle(
        "hidden",
        !section.querySelector(`.${selectedCategory}`)
      );
    }
  });
});
